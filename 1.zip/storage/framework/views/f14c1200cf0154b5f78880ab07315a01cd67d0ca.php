<div class="col-md-2">
    <div class="list-group">
        <a href="<?php echo e(route('cabinet.settings')); ?>" class="list-group-item list-group-item-action"><?php echo e(__('cab.language')); ?></a>
        <a href="<?php echo e(route('cabinet.settings.password')); ?>" class="list-group-item list-group-item-action"><?php echo e(__('cab.password')); ?></a>
    </div>
</div>