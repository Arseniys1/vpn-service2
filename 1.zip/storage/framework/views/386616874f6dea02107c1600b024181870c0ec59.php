<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <?php echo $__env->make('cabinet.cab_settings_nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="col-md-6">
                <div class="card">
                    <div class="card-header"><?php echo e(__('cab.settings')); ?></div>

                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <p class="text-success"><?php echo e(__('cab.data_save')); ?></p>
                        <?php elseif(session('error')): ?>
                            <p class="text-danger"><?php echo e(__('cab.error')); ?></p>
                        <?php endif; ?>

                        <form action="<?php echo e(route('cabinet.settings.save')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="locale"><?php echo e(__('cab.language')); ?></label>
                                <select class="form-control" name="locale" id="locale">
                                    <option value="ru">Русский</option>
                                    <option value="en">English</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary"><?php echo e(__('cab.save')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>