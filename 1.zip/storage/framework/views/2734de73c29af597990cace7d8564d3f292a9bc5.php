<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <?php echo $__env->make('cabinet.cab_settings_nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="col-md-6">
                <div class="card">
                    <div class="card-header"><?php echo e(__('cab.settings')); ?></div>

                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <p class="text-success"><?php echo e(__('cab.data_save')); ?></p>
                        <?php elseif(session('error')): ?>
                            <?php if(session('error_message')): ?>
                                <p class="text-danger"><?php echo e(session('error_message')); ?></p>
                            <?php else: ?>
                                <p class="text-danger"><?php echo e(__('cab.error')); ?></p>
                            <?php endif; ?>
                        <?php endif; ?>

                        <form action="<?php echo e(route('cabinet.settings.password.save')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="password_current"><?php echo e(__('cab.password_current')); ?></label>
                                <input id="password_current" type="password" class="form-control<?php echo e($errors->has('password_current') ? ' is-invalid' : ''); ?>" name="password_current" required>
                            </div>

                            <div class="form-group">
                                <label for="password"><?php echo e(__('login.password')); ?></label>
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label for="password_confirmation"><?php echo e(__('login.password_confirm')); ?></label>
                                <input id="password_confirmation" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                            <button type="submit" class="btn btn-primary"><?php echo e(__('cab.save')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>