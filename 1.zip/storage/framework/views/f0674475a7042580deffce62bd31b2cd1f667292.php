<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 mb-3">
                <div class="card">
                    <div class="card-header"><?php echo e(__('servers.' . $title)); ?></div>

                    <div class="card-body">
                        <?php if(count($servers) > 0): ?>
                            <?php $__currentLoopData = $servers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $server): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card mb-2">
                                    <div class="card-body">
                                        <?php echo e($server->ip . ':' . $server->port); ?>

                                        <?php echo e($server->country->name . ' ' . $server->country->iso); ?>

                                        <img src="<?php echo e(asset('images/countries/' . $server->country->image)); ?>">
                                        Online <?php echo e($server->online_counter . '/' . $server->max_online); ?>

                                        <?php if(Auth::check() || $server->free == true): ?>
                                            <a href="#" name="sendRequest" data-ip="<?php echo e($server->ip); ?>">Получить доступ</a>
                                            <a href="<?php echo e(route('cabinet.downloadOvpnConfig', ['ip' => $server->ip])); ?>" style="display: none;">Скачать конфигурацию</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php echo e($servers->links()); ?>

                        <?php else: ?>
                            <p><?php echo e(__('servers.no_servers')); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>