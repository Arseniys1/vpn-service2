<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><?php echo e(__('cab.subs')); ?></div>

                    <div class="card-body">
                        <?php $__currentLoopData = Auth::user()->access; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $access): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($access->pivot->end_at > time()): ?>
                                <div class="card text-white bg-primary mb-3">
                                    <div class="card-header"><?php echo e(__('cab.' . $access->name_humanity)); ?></div>
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e(__('cab.duration') . __('cab.' . $access->duration_humanity)); ?></h5>
                                        <h5 class="card-title"><?php echo e(__('cab.price') . $access->price / 100 . '$'); ?></h5>
                                        <p class="card-text">
                                            <?php
                                            $now = new DateTime();
                                            $end_at = new DateTime();
                                            $end_at->setTimestamp($access->pivot->end_at);
                                            $interval = $now->diff($end_at);
                                            ?>
                                            <?php echo e(__('cab.left') . $interval->y . __('cab.years_old') . $interval->d . __('cab.days') . $interval->h . __('cab.hours') . $interval->i . __('cab.minutes')); ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if(!Auth::user()->hasActiveAccess()): ?>
                            <a class="btn btn-success" role="button" style="color: #fff;">
                                <?php echo e(__('cab.buy_sub')); ?>

                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>