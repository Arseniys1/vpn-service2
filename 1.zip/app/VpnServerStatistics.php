<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VpnServerStatistics extends Model
{
    protected $table = 'vpn_servers_statistics';
}
