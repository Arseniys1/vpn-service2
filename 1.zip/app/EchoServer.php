<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EchoServer extends Model
{
    protected $table = 'echo_servers';

    public $timestamps = false;
}
