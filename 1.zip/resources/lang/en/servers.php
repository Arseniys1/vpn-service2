<?php

return [
    'servers_title' => 'Servers',
    'free_servers_title' => 'Free servers',
    'no_servers' => 'No servers!',
];