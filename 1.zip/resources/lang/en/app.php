<?php

return [
    'login' => 'Login',
    'register' => 'Registration',
    'logout' => 'Logout',
    'settings' => 'Settings',
    'cabinet' => 'Cabinet',
    'servers_list' => 'Servers list',
    'free_servers_list' => 'Free servers list',
];