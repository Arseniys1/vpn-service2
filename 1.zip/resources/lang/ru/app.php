<?php

return [
    'login' => 'Войти',
    'register' => 'Регистрация',
    'logout' => 'Выход',
    'settings' => 'Настройки',
    'cabinet' => 'Кабинет',
    'servers_list' => 'Список серверов',
    'free_servers_list' => 'Список бесплатных серверов',
];