<?php

return [
    'servers_title' => 'Сервера',
    'free_servers_title' => 'Бесплатные сервера',
    'no_servers' => 'Серверов нет!',
];