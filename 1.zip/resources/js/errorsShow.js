const errorsShowApp = new Vue({
    el: '#errors-show',
});