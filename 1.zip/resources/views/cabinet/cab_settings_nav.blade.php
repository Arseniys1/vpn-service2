<div class="col-md-2">
    <div class="list-group">
        <a href="{{ route('cabinet.settings') }}" class="list-group-item list-group-item-action">{{ __('cab.language') }}</a>
        <a href="{{ route('cabinet.settings.password') }}" class="list-group-item list-group-item-action">{{ __('cab.password') }}</a>
    </div>
</div>